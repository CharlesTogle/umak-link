export default function AuditLogs () {
  return <div>Audit Logs</div>
}
