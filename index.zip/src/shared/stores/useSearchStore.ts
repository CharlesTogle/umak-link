export { useSearchContext as useSearchStore } from '@/shared/contexts/SearchContext'
