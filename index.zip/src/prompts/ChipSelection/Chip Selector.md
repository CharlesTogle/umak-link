![[Pasted image 20251022162514.png]]![[Pasted image 20251022162527.png]]


I need you to create 2 components
1. A chips that has 2 states(Active, SelectionTrigger)
2. A Select category component similar to the one above

To Create the Chip Button component with 2 states use IonChip and onClick to open the Select Category

The state of the category chip will be determined by 
1. If user selected in the CategorySelection component which will be either an overlay or an action sheet, but I don't think an action sheet will work
2. The active chip should have an X icon beside it
3. If user clicked a chip that has an Active state then remove it as the category
4. Think of ways on how the RemoveSelection will move to Active again if the user did not remove it

in SelectCategory use a flexbox to do it

Here are my requirements
1. A new component named CategorySelection (the overlay), which will display all the available chips, truncated if there are too many, make sure it covers 1/3 of the screen
2. A new component that has 2 states (Active, SelectionTrigger) which is named CategorySelectionTrigger
3. An edited payload and validation in the handlePayload
4. Make sure to make the frontend 1:1 to the images

![[Pasted image 20251022162554.png]]

Here is the type for CreatePost
```ts
export interface CreatePostInput {
  anonymous: boolean
  item: {
    title: string
    desc: string
    type: PostType
  }
  lastSeenISO: string
  locationDetails: {
    level1: string
    level2: string
    level3: string
  }
  imageName: string
  image: File
}
```

Here is the current new post component

```js
import { useState } from 'react'
import {
  IonContent,
  IonIcon,
  IonButton,
  IonSpinner,
  IonChip
} from '@ionic/react'
import ImageUpload from '@/shared/components/ImageUpload'
import LocationDetailsSelector from '@/features/user/components/shared/LocationDetailsSelector'
import LastSeenModal from '@/features/user/components/shared/LastSeenModal'
import ItemStatusSelector from '@/features/user/components/shared/ItemStatusSelector'
import Header from '@/shared/components/Header'
import { create } from 'ionicons/icons'
import { useNavigation } from '@/shared/hooks/useNavigation'
import { IonToast } from '@ionic/react'
import { useUser, type User } from '@/features/auth/contexts/UserContext'
import { postServices } from '../services/postServices'
  
/** ---------- Helpers ---------- */
const toISODate = (date: string, time: string, meridian: 'AM' | 'PM') => {
  const [month, day, year] = date.split('/')
  let [hours, minutes] = time.split(':').map(Number)
  if (meridian === 'PM' && hours < 12) hours += 12
  if (meridian === 'AM' && hours === 12) hours = 0
  return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${String(
    hours
  ).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00+08:00`
}
  
/** ---------- Component ---------- */
export default function NewPost () {
  // time defaults (PH time)
  const now = new Date()
  const utc = now.getTime() + now.getTimezoneOffset() * 60000
  const ph = new Date(utc + 8 * 3600000)
  let hh = ph.getHours()
  const mm = ph.getMinutes().toString().padStart(2, '0')
  const meridianInit = hh >= 12 ? 'PM' : 'AM'
  hh = hh % 12 || 12
  

  // stat

  const errorMessage, setErrorMessage] = useState('') // for error message

  const [showToast, setShowToast] = useState(false)

  const [toastColor, setToastColor] = useState<'danger' | 'success'>('danger')

  const [anonymous, setAnonymous] = useState<'no' | 'yes'>('no')

  const [title, setTitle] = useState('')

  const [desc, setDesc] = useState('')

  const [type, setType] = useState<'lost' | 'found'>('lost')

  const [date, setDate] = useState(

    ph.toLocaleDateString('en-US', {

      month: '2-digit',

      day: '2-digit',

      year: 'numeric'

    })

  )

  const [time, setTime] = useState(`${hh}:${mm}`)

  const [meridian, setMeridian] = useState(meridianInit as 'AM' | 'PM')

  const [image, setImage] = useState<File | null>(null)

  const [locationDetails, setLocationDetails] = useState({

    level1: '',

    level2: '',

    level3: ''

  })

  const [loading, setLoading] = useState(false)

  const { navigate } = useNavigation()

  const { getUser } = useUser()

  const { createPost } = postServices

  

  const handleDateChange = (e: CustomEvent) => {

    const iso = e.detail.value as string

    if (!iso) return

    const d = new Date(iso)

    const formattedDate = d.toLocaleDateString('en-US', {

      month: '2-digit',

      day: '2-digit',

      year: 'numeric',

      timeZone: 'Asia/Manila'

    })

    let hours = d.getHours()

    const mins = d.getMinutes().toString().padStart(2, '0')

    const mer = hours >= 12 ? 'PM' : 'AM'

    hours = hours % 12 || 12

    setDate(formattedDate)

    setTime(`${hours}:${mins}`)

    setMeridian(mer as 'AM' | 'PM')

  }

  

  const handleCancel = () => {

    navigate('/user/home')

  }

  

  const handleSubmit = async () => {

    setLoading(true)

    let currentUser: User | null = null

    try {

      currentUser = await getUser()

    } catch (error) {

      console.error('Error fetching user:', error)

      setLoading(false)

      setErrorMessage('Failed to authenticate user')

      setToastColor('danger')

      setShowToast(true)

      return

    }

    // Trim text inputs

    const titleTrimmed = title.trim()

    const descTrimmed = desc.trim()

  

    // Validate required fields

    if (

      !titleTrimmed ||

      !descTrimmed ||

      !image ||

      !locationDetails.level1.trim() ||

      !locationDetails.level2.trim() ||

      !locationDetails.level3.trim() ||

      !type ||

      !date ||

      !time ||

      !meridian

    ) {

      setErrorMessage('Please fill in all required fields.')

      setToastColor('danger')

      setShowToast(true)

      setLoading(false)

      return

    }

  

    const payload = {

      anonymous: anonymous === 'yes',

      item: {

        title: titleTrimmed,

        desc: descTrimmed,

        type

      },

      lastSeenISO: toISODate(date, time, meridian),

      locationDetails: {

        level1: locationDetails.level1.trim(),

        level2: locationDetails.level2.trim(),

        level3: locationDetails.level3.trim()

      },

      imageName: image.name,

      image: image

    }

  

    console.log('Submitting New Post:', payload)

  

    try {

      if (!currentUser) {

        throw new Error('No Error is logged in')

      }

      const result = await createPost(currentUser.user_id, payload)

  

      if (result.error) {

        setErrorMessage(result.error)

        setToastColor('danger')

        setShowToast(true)

        setLoading(false)

        return

      }

  

      // Success

      setErrorMessage('Post created successfully!')

      setToastColor('success')

      setShowToast(true)

      setLoading(false)

  

      // Navigate after a brief delay to show the toast

      setTimeout(() => {

        navigate('/user/home')

      }, 1000)

    } catch (error) {

      console.error('Error creating post:', error)

      setErrorMessage('Failed to create post')

      setToastColor('danger')

      setShowToast(true)

      setLoading(false)

    }

  }

  

  return (

    <IonContent>

      <div className='fixed top-0 w-full z-999'>

        <Header logoShown={false}>

          <div className='flex justify-between items-center bg-[#1e2b87] ion-padding-start ion-padding-end'>

            <IonButton

              style={{

                '--background': 'var(--color-umak-red)',

                '--box-shadow': 'none'

              }}

              onClick={handleCancel}

            >

              Cancel

            </IonButton>

            <div className='flex items-center space-x-2 w-fit h-fit border-1 border-white rounded-md'>

              <IonButton

                style={{

                  '--background': 'transparent',

                  '--box-shadow': 'none'

                }}

                onClick={handleSubmit}

                disabled={loading}

              >

                {loading ? <IonSpinner name='crescent' /> : 'Submit'}

              </IonButton>

            </div>

          </div>

        </Header>

      </div>

      <div className=' bg-gray-50 mb-5 w-full mt-14 font-default-font'>

        <div className='mt-3 shadow-md p-4 border border-gray-200'>

          <div className='flex items-center space-x-2'>

            <IonIcon

              icon={create}

              className='text-[#1e2b87]'

              style={{ fontSize: '32px', ['--ionicon-stroke-width']: '40px' }}

            />

            <div className='text-umak-blue font-default-font text-base font-normal'>

              New Post

            </div>

          </div>

          <div className='w-full h-px bg-slate-900 my-3' />

          <div>

            {/* ANONYMOUS RADIO */}

            <div className='mb-4'>

              <p className='font-default-font text-xl mb-2 text-slate-900 font-extrabold flex items-center'>

                Upload as anonymous?

                <span className='text-umak-red font-default-font text-sm font-normal ml-3'>

                  (for reporters only)

                </span>

              </p>

              <div className='flex flex-row justify-start gap-10'>

                <label className='flex justify-center cursor-pointer select-none'>

                  <input

                    type='radio'

                    className='appearance-none w-4 h-4 border border-gray-400 rounded-full checked:border-[5px] checked:border-[#1e2b87] transition-all'

                    checked={anonymous === 'no'}

                    onChange={() => setAnonymous('no')}

                  />

                  <span className='text-md ml-2 text-gray-800'>No</span>

                </label>

                <label className='flex justify-center cursor-pointer select-none'>

                  <input

                    type='radio'

                    className='appearance-none w-4 h-4 border border-gray-400 rounded-full checked:border-[5px] checked:border-[#1e2b87] transition-all'

                    checked={anonymous === 'yes'}

                    onChange={() => setAnonymous('yes')}

                  />

                  <span className='text-md ml-2 text-gray-800'>Yes</span>

                </label>

              </div>

            </div>

            {/* ITEM NAME */}

            <div className='mb-4'>

              <p className='font-default-font text-xl mb-2 text-slate-900 font-extrabold flex items-center'>

                Item Name/Title

                <span className='text-umak-red font-default-font text-sm font-normal ml-2'>

                  (required)

                </span>

              </p>

              <input

                type='text'

                className='border-2 border-black rounded-xs py-1 px-2 w-full focus:border-2-umak-blue focus:outline-none font-default-font text-base'

                value={title}

                placeholder='Max 32 characters'

                maxLength={32}

                onChange={e => setTitle(e.target.value)}

                required

              />

            </div>

  

            <div className='mb-4'>

              <p className='font-default-font text-xl mb-2 text-slate-900 font-extrabold flex items-center'>

                Description

              </p>

              <textarea

                className={`border-2 max-h-25 border-black rounded-xs py-1 px-2 w-full

                  focus:border-2-umak-blue focus:outline-none font-default-font

                  text-base overflow-hidden`}

                value={desc}

                placeholder='Max 150 characters'

                maxLength={150}

                onChange={e => {

                  setDesc(e.target.value)

                  const target = e.target

                  target.style.height = 'auto'

                  target.style.height = target.scrollHeight + 'px'

                }}

              />

            </div>

            <div className='pr-5'>

              <ItemStatusSelector

                value={type}

                onChange={value => setType(value as 'lost' | 'found')}

                isRequired={true}

              />

            </div>

            <LastSeenModal

              handleDateChange={handleDateChange}

              date={toISODate(date, time, meridian)}

              isRequired={true}

            />

            <div>

              <p className='font-default-font text-xl mb-2 text-slate-900 font-extrabold flex items-center'>

                Category

                <span className='text-umak-red font-default-font text-sm font-normal ml-2'>

                  (required)

                </span>

              </p>

              <IonChip></IonChip>

            </div>

            <LocationDetailsSelector

              locationDetails={locationDetails}

              setLocationDetails={setLocationDetails}

              isRequired={true}

            />

            <ImageUpload

              label='Image'

              image={image}

              onImageChange={setImage}

              isRequired={true}

            />

            <div className='rounded-md overflow-hidden'>

              <IonButton

                style={{ '--background': 'var(--color-umak-blue)' }}

                expand='full'

                onClick={handleSubmit}

                disabled={loading}

              >

                {loading ? <IonSpinner name='crescent' /> : 'Submit'}

              </IonButton>

            </div>

          </div>

        </div>

      </div>

      <IonToast

        isOpen={showToast}

        onDidDismiss={() => setShowToast(false)}

        message={errorMessage}

        duration={2000}

        color={toastColor}

        position='bottom'

      />

    </IonContent>

  )

}
```