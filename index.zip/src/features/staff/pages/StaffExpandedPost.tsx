export default function StaffExpandedPost() {
  return (
    <div>
      
    </div>
  );
}